package in.ashokit.entity;

import lombok.Data;

@Data
public class Summary 
{
	
	private Integer caseNo;
	private Integer empIncome;
	private Integer rentIncome;
	private Integer propertyIncome;
	
	

}
