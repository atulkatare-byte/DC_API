package in.ashokit.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
@Data
public class DcIncome 
{
	@Id
	@GeneratedValue
	private Integer incomeId;
	
	private Integer caseNum;
	
	private Integer empIncome;
	
	private Integer propertyIncome;
	
	private String createdBy;
	private String updatedBy;
	
	@Column(updatable = false)
	@CreationTimestamp
	private LocalDate createdDate;
	
	@Column(insertable  = false)
	@UpdateTimestamp
	private LocalDate updatedDate;

}
