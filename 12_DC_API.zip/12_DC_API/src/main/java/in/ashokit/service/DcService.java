package in.ashokit.service;

import java.util.Collection;
import java.util.List;

import in.ashokit.entity.DcChildrens;
import in.ashokit.entity.DcIncome;
import in.ashokit.entity.Education;

public interface DcService 
{
	public boolean findAppId (Integer appId);
	
	public boolean savePlan(Integer appId,Integer caseId,Integer planId);
	
	public boolean saveIncome(DcIncome income);
	
	public boolean saveEducation(Education education);
	
	public boolean saveKid(List<DcChildrens> dcChildrens);
	
	public DcIncome getSummary(Integer caseNum);
	
	

}
