package in.ashokit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import in.ashokit.entity.DcCase;
import in.ashokit.entity.DcChildrens;
import in.ashokit.entity.DcIncome;
import in.ashokit.entity.Education;

import in.ashokit.repo.Case;
import in.ashokit.repo.ChildrenRepo;
import in.ashokit.repo.EducationRepo;
import in.ashokit.repo.Income;

public class DcServiceImpl implements DcService {

	@Autowired
	private Case cas;
	
	@Autowired
	private Income inco;
	
	@Autowired
	private EducationRepo edu;
	
	@Autowired
	private ChildrenRepo child;
	
	@Override
	public boolean findAppId(Integer appId) {
		
		Optional<DcCase> appis=cas.findById(appId);
		
		if(appis.isPresent())
			return true;
		else
			return false;
			
	}

	@Override
	public boolean savePlan(Integer appId, Integer caseId, Integer planId) {
		DcCase dc=new DcCase();
		dc.setAppId(appId);
		dc.setCaseNum(caseId);
		dc.setPlanId(planId);
		
		DcCase dce=cas.save(dc);
		return dce.getAppId()!=null;
	}

	@Override
	public boolean saveIncome(DcIncome income) {
		
		DcIncome saved=inco.save(income);
		
		return saved.getCaseNum()!=null;
	}

	@Override
	public boolean saveEducation(Education education) {
		
		Education sav=edu.save(education);
		
		return sav.getEduId()!=null;
	}

	@Override
	public boolean saveKid(List<DcChildrens> dcChildrens) {
		
		List<DcChildrens> list= child.saveAll(dcChildrens);
		 if(list.isEmpty())
			 return false;
		 else
			 return true;
	}

	@Override
	public Optional<DcIncome> getSummary(Integer caseNum) 
	{
		//Optional<DcIncome> get=inco.findById(caseNum);
		return inco.findById(caseNum);
	}

}
